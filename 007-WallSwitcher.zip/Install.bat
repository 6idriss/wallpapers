@echo off
:: Double-click to install 007 Wall Switcher (Desktop + Start Menu shortcuts).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
pause
