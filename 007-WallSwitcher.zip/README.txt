007 WALL SWITCHER  v1.0.0
==========================

Your wallpaper library and auto-changer for Windows 10 and 11.

INSTALL
  Double-click Install.bat. It adds shortcuts to your Desktop and Start Menu.
  Or double-click "Run Wall Switcher.bat" to try it without installing.

WHAT IT DOES
  - Add pictures or whole folders (or drag them in). Click a picture to set it.
  - Change the wallpaper every 1 minute to 1 day, in order or shuffled.
  - Pick a screen, or put a different picture on each screen.
  - Change the lock screen too.
  - Time of day: a different folder for morning, day, evening and night.
  - Quick picker: press Ctrl + Alt + W anywhere to pick a wallpaper.
  - Starts with Windows and lives in the tray, next to the clock.

FREE TRIAL AND KEY
  Free for 3 days. Then buy a key for $2.99 (Whish or crypto):
  https://6idriss.github.io/wallpapers/#switcher
  Paste the key in the app with "Enter key".

UNINSTALL
  Double-click Uninstall.bat. Your pictures are never touched.

Help: https://discord.gg/FjSraGbJPa
