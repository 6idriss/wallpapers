@echo off
:: Double-click to run 007 Wall Switcher without installing.
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0WallSwitcher.ps1"
