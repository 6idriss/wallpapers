@echo off
:: Double-click to remove 007 Wall Switcher. Your pictures are not touched.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -Uninstall
pause
